﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntSetCLI
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1
            Console.WriteLine("1. CREATE. Create set with n elements capacity");
            int capacity = Int32.Parse(Console.ReadLine());
            IntSet set = new IntSet(capacity);
            IntSet set2 = new IntSet(capacity);
            
            //2
            Console.WriteLine($"2. INSERT. Populate set with {capacity} elements\n");
            Random rnd = new Random();
            for (int i = 0; i < capacity; i++)
            {
                set.Insert(rnd.Next(0, 100));
            }

            //3
            Console.WriteLine("3. SHOW. Display set elements");
            Console.WriteLine(set);
            Console.ReadKey();
            
            //4
            Console.WriteLine("4. DELETE. Delete element from set");
            Console.WriteLine("Input element for deleting: ");
            int elem = Int32.Parse(Console.ReadLine());
            set.Delete(elem);
            Console.WriteLine("\nSet elemets after deletion:");
            Console.WriteLine(set);

            Console.ReadKey();
        }
    }
}