﻿using System;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace IntSetCLI
{
    [Serializable]
    class IntSet
    {
        private int[] body;
        private int Count;
        private int MaxSize;

        public IntSet(int size)
        {
            Count = 0;
            MaxSize = size;
            body = new int[MaxSize];
        }

        public void Insert(int item)
        {
            try
            {
                InsertionProc(item);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void Delete(int item)
        {
            try
            {
                DeletionProc(item);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public IntSet Copy()
        {
            using (var ms = new MemoryStream())
            {
                var formatter = new BinaryFormatter();

                formatter.Serialize(ms, this);
                ms.Position = 0;

                return (IntSet)formatter.Deserialize(ms);
            }
        }

        public bool Member(int item)
        {
            for (int i = 0; i < Count; i++)
            {
                if (item == body[i])
                {
                    return true;
                }
            }
            return false;
        }

        public int Size()
        {
            return Count;
        }

        public int Choose()
        {
            try
            {
                return body[new Random().Next(0, Count - 1)];
            }
            catch (ArgumentOutOfRangeException)
            {
                throw;
            }
        }

        public bool Equal(IntSet other)
        {
            return this.Equals(other) ? true : false;
        }

        public bool Similar(IntSet other)
        {
            return this.ToString() == other.ToString() ? true : false;
        }

        public void Destroy()
        {
            Console.WriteLine("Memory used before collection: {0:N0}", GC.GetTotalMemory(false));
            GC.Collect();
            Console.WriteLine("Memory used before collection: {0:N0}", GC.GetTotalMemory(true));
        }

        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < Count; i++)
            {
                yield return body[i];
            }
            Console.WriteLine("Hello from custom enumerator");
        }

        public override string ToString()
        {
            StringBuilder stb = new StringBuilder();
            stb.Append("Set of items: ");
            foreach (var item in body)
            {
                stb.Append($"{item}  ");
            }

            return stb.ToString();
        }

        /*---------------------------private methods---------------------------*/
        private void InsertionProc(int item)
        {
            if (Count.Equals(MaxSize))
            {
                throw new Exception("Set is full. You can't insert new element");
            }

            if (Count.Equals(0))
            {
                body[Count++] = item;
            }
            else
            {
                for (int i = 0; i < Count; i++)
                {
                    if (item > body[i])
                    {
                        int position = i;
                        for (int j = Count - 1; j >= position; j--)
                        {
                            body[j + 1] = body[j];
                        }
                        body[position] = item;
                        Count++;
                        return;
                    }
                }
                body[Count++] = item;
            }
        }

        private void DeletionProc(int item)
        {
            if (Count.Equals(0))
            {
                throw new ArgumentException("Set is empty. You can't delete element");
            }

            for (int i = 0; i < Count; i++)
            {
                if (item == body[i])
                {
                    int position = i;
                    for (int j = position; j < Count - 1; j++)
                    {
                        body[j] = body[j + 1];
                    }
                    body[Count - 1] = 0;
                }
                else
                {
                    Console.WriteLine($"There is no element {item} in the set");
                    break;
                }
            }
        }

    }
}
