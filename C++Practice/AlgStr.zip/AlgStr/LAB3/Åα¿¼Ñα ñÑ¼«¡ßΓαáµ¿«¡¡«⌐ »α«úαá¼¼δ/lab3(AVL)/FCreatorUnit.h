//---------------------------------------------------------------------------

#ifndef FCreatorUnitH
#define FCreatorUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFCreator : public TForm
{
__published:	// IDE-managed Components
        TRichEdit *RichEdit1;
        TBitBtn *BitBtn1;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall RichEdit1KeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
        __fastcall TFCreator(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFCreator *FCreator;
//---------------------------------------------------------------------------
#endif
