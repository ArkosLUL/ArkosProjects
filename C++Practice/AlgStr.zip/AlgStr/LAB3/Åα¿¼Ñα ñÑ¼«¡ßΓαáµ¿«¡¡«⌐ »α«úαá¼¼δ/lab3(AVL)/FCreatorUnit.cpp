//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FCreatorUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFCreator *FCreator;
//---------------------------------------------------------------------------
__fastcall TFCreator::TFCreator(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFCreator::FormActivate(TObject *Sender)
{
  FCreator->Left = Screen->Width / 2 - FCreator->Width / 2;
  FCreator->Top  = Screen->Height / 2 - FCreator->Height / 2;

  BitBtn1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFCreator::FormCreate(TObject *Sender)
{
  try
  {
     RichEdit1->Lines->LoadFromFile("AboutCreator.txt");
  }
  catch(...)
  {
     MessageDlg("File \"AboutCreator.txt\" wasn't found!\nYou cannot looking information about creator",
                 mtError, TMsgDlgButtons() << mbOK, 0);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFCreator::BitBtn1Click(TObject *Sender)
{
  FCreator->Close();        
}
//---------------------------------------------------------------------------
void __fastcall TFCreator::RichEdit1KeyPress(TObject *Sender, char &Key)
{
  Key = 0;        
}
//---------------------------------------------------------------------------
