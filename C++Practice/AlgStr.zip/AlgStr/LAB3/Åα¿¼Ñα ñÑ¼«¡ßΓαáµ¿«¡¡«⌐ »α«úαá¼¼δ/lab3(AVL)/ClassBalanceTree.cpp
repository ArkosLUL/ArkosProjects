//---------------------------------------------------------------------------


#pragma hdrstop

#include "ClassBalanceTree.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

BalanceTree::BalanceTree(Node* R)
{
  root = R;
  CopyElem(R);
}

BalanceTree::BalanceTree(const BalanceTree& copyTree)
{
  CopyElem(copyTree.root);
}

void BalanceTree::CopyElem(Node* serc)
{
  if(serc)
  {
     this->AddItem(serc->item);
     if(serc->LeftRoot)  CopyElem(serc->LeftRoot);
     if(serc->RightRoot) CopyElem(serc->RightRoot);
  }
}

BalanceTree::~BalanceTree()
{
  DelAll(root);
}

void BalanceTree::CleanTree()
{
  DelAll(root);
}

void BalanceTree::DelAll(Node*& R)
{
  if(R)
  {
     DelAll(R->LeftRoot);
     DelAll(R->RightRoot);
     delete R;
  }
}

void BalanceTree::RotateSingleLL(Node*& R)
{
  Node *r1 = R->LeftRoot;//temp link

  if(r1->bal == static_cast<Balance>(-1))
  {
     R->bal = static_cast<Balance>(0);
     r1->bal = static_cast<Balance>(0);
  }
  else
  {
     R->bal = static_cast<Balance>(-1);
     r1->bal = static_cast<Balance>(1);
  }
  R->LeftRoot = r1->RightRoot;
  r1->RightRoot = R;
  R = r1;
}

void BalanceTree::RotateSingleRR(Node*& R)
{
  Node *r1 = R->RightRoot;// it's temp link too


  if(r1->bal == static_cast<Balance>(1))
  {
     R->bal = static_cast<Balance>(0);
     r1->bal = static_cast<Balance>(0);
  }
  else
  {
     R->bal = static_cast<Balance>(1);
     r1->bal = static_cast<Balance>(-1);
  }
  R->RightRoot = r1->LeftRoot;
  r1->LeftRoot = R;
  R = r1;
}

void BalanceTree::RotateDoubleRL(Node*& R)
{
  Node *r1 = R->LeftRoot, *r2 = r1->RightRoot;//two tempering(?) link

  if(r2->bal == static_cast<Balance>(1))
  {
     r1->bal = static_cast<Balance>(-1);
  }
  else
  {
     r1->bal = static_cast<Balance>(0);
  }

  if(r2->bal == static_cast<Balance>(-1))
  {
     R->bal = static_cast<Balance>(1);
  }
  else
  {
     R->bal = static_cast<Balance>(0);
  }

  R->LeftRoot = r2->RightRoot;
  r1->RightRoot = r2->LeftRoot;
  r2->LeftRoot = r1;
  r2->RightRoot =R;

  R = r2;
}

void BalanceTree::RotateDoubleLR(Node*& R)
{
  Node *r1 = R->RightRoot, *r2 = r1->LeftRoot;//two tempering(?) link

  if(r2->bal == static_cast<Balance>(-1))
  {
     r1->bal = static_cast<Balance>(1);
  }
  else
  {
     r1->bal = static_cast<Balance>(0);
  }

  if(r2->bal == static_cast<Balance>(1))
  {
     R->bal = static_cast<Balance>(-1);
  }
  else
  {
     R->bal = static_cast<Balance>(0);
  }

  R->RightRoot = r2->LeftRoot;
  r1->LeftRoot = r2->RightRoot;
  r2->RightRoot = r1;
  r2->LeftRoot =R;

  R = r2;
}

void BalanceTree::BalanceL(Node*& R,bool& h)
//left tree have been shorter
{
   switch(R->bal)
   {
     case -1  : R->bal = static_cast<Balance>(0); /*R->bal++*/ break;
     case  0  : R->bal = static_cast<Balance>(1); h = false;   break;
     case  1  :
                if(R->RightRoot->bal == static_cast<Balance>(-1))
                {
                   RotateDoubleRL(R);
                }
                else
                {
                   RotateSingleRR(R);
                }
                h = false;
                break;
   }
}

void BalanceTree::BalanceR(Node*& R,bool& h)
//Heavy left tree, becouse right have been shorter
{
   switch(R->bal)
   {
     case  1  : R->bal = static_cast<Balance>(+0); /*R->bal++*/ break;// (+0)-> :)
     case  0  : R->bal = static_cast<Balance>(-1); h = false;   break;
     case -1  :
                if(R->RightRoot->bal == static_cast<Balance>(-1))
                {
                   RotateDoubleLR(R);
                }
                else
                {
                   RotateSingleLL(R);
                }
                h = false;
                break;
   }
}

void BalanceTree::Search(int key, Node*& R, bool& h)
//searching root with item = Key and Paste
//R - pointer to root of tree
{
  Node *r1, *r2;//declaration temp link

  if(!R)//emty tree
  {
     R = new Node;
     h = true;
     R->item = key;
     R->count = 1;
  }
  else if(key < R->item)//go to right tree
       {
          Search(key,R->LeftRoot,h);//Searching good place in the left root
          if(h)//if we must change balance index
          {
             switch(R->bal)//HeavyLeft
             {
               case  1    : R->bal = static_cast<Balance>( 0) ; h = false; break;
               case  0    : R->bal = static_cast<Balance>(-1);             break;
               case -1    : /* balance */  //HeavyLeft realy
                                 r1 = R->LeftRoot;
                                 if(r1->bal == static_cast<Balance>(-1))
                                 {//LL-rectangle
                                    R->LeftRoot = r1->RightRoot;
                                    r1->RightRoot = R;
                                    R->bal = static_cast<Balance>(0);
                                    R = r1;
                                 }
                                 else
                                 {//double LR-rectangle
                                    r2 = r1->RightRoot;
                                    r1->RightRoot = r2->LeftRoot;
                                    r2->LeftRoot = r1;
                                    R->LeftRoot = r2->RightRoot;
                                    r2->RightRoot = R;
                                    if(r2->bal == static_cast<Balance>(-1)) R->bal = static_cast<Balance>(1);
                                    else R->bal = static_cast<Balance>(0);
                                    if(r2->bal == static_cast<Balance>(1)) r1->bal = static_cast<Balance>(-1);
                                    else r1->bal= static_cast<Balance>(0);
                                    R = r2;
                                 }
                                 R->bal = static_cast<Balance>(0);
                                 h = false;// we change balance index at once
                                 break;
               default: throw EnumError();
             }
          }
       }
       else if(key > R->item)
            {
               Search(key,R->RightRoot,h);// ... right root
               if (h)
               {
                   switch(R->bal)//HeavyRight
                   {
                     case -1: R->bal = static_cast<Balance>( 0);  h = false; break;
                     case  0: R->bal = static_cast<Balance>( 1);             break;
                     case  1: /* balance */
                                       r1 = R->RightRoot;
                                       if(r1->bal == static_cast<Balance>( 1))
                                       {//RR-rectangle
                                          R->RightRoot = r1->LeftRoot;
                                          r1->LeftRoot = R;
                                          R->bal = static_cast<Balance>(0); R = r1;
                                       }
                                       else
                                       {//double RL-rectangle
                                          r2 = r1->LeftRoot;
                                          r1->LeftRoot = r2->RightRoot;
                                          r2->RightRoot = r1;
                                          R->RightRoot = r2->LeftRoot;
                                          r2->LeftRoot = R;
                                          if(r2->bal == static_cast<Balance>( 1))
                                             R->bal = static_cast<Balance>(-1);
                                          else R->bal = static_cast<Balance>( 0);
                                          if(r2->bal == static_cast<Balance>(-1))
                                             r1->bal = static_cast<Balance>( 1);
                                          else r1->bal = static_cast<Balance>( 0);
                                          R = r2;
                                       }
                                       R->bal = static_cast<Balance>(0); h = false;
                                       break;
                     default: throw EnumError();
                   }
               }
            }
            else R->count++;
}

void BalanceTree::Del(Node*& r,Node*& q,bool& h)
//helping procedure for deleting link - q
{         
     if(r->RightRoot)
     {
        Del(r->RightRoot,q,h);
        if(h) BalanceR(r,h);
     }
     else
     {
        q->item = r->item;
        q->count = r->count;
        q = r;
        r = r->LeftRoot;
        h = true;
     }
}

void BalanceTree::Delete(int key, Node*& R,bool& h)
{
    if(!R)//key doesn't exist
    {
       throw KeyNotExist(key);
    }
    else
    if(key < R->item)//goto left tree
    {
       Delete(key,R->LeftRoot,h);
       if(h) BalanceL(R,h);
    }
    else
    if(key > R->item)//goto right tree
    {
       Delete(key,R->RightRoot,h);
       if(h) BalanceR(R,h);
    }
    else//we find link and must delete it
    {
       Node* DelLink = R;
       if(!R->RightRoot)//we uping left tree
       {
          R = R->LeftRoot;
          h = true;
       }
       else
       if(!R->LeftRoot)//... right tree
       {
          R = R->RightRoot;
          h = true;
       }
       else
       {
          Del(R->LeftRoot,DelLink,h);// delete with balance
          if(h) BalanceL(R,h);
       }
       delete DelLink;
    }
}

void BalanceTree::AddItem(int item)
//this is public function for iterface of tree, it hide recusive calling
{
    bool Hibno = false;// becouse compilator is full and show me warning
    Search(item,root,Hibno);
}

void BalanceTree::DeleteItem(int item)
//...
{
    bool Hibno = false;
    Delete(item,root,Hibno);
}

void BalanceTree::Load(const AnsiString& way)
//this function load items from file
{
    std::fstream f;
    f.open(way.c_str(),std::ios::in);
    if(!f) throw FileNotExist(way);
    int buf;
    while(!f.eof())
    {
      f>>buf;
      AddItem(buf);
    }
    f.close();
}

void BalanceTree::write(Node*& R,std::fstream& f)
{
    if(R)
    {
        f<<R->item<<' ';
        write(R->LeftRoot,f); //f<<'\n'; // for quick test on balance
        write(R->RightRoot,f);
    }
}

void BalanceTree::Save(const AnsiString& way)
//write items to file(interface)
{
    std::fstream f;
    f.open(way.c_str(), std::ios::out|std::ios::trunc);
    if(!f) throw FileNotExist(way);
    write(root,f);
    f.close();
}

int max(int a, int b)
{
   return a > b? a : b;// if a > b then return a else return b
}

int min(int a, int b)
{
   return a < b? a : b;// if a < b then return a else return b
}

int BalanceTree::RecursiveHeight(Node* t)
{
    if(t)//curent root not empty
    {
       return 1 + max(RecursiveHeight(t->LeftRoot),RecursiveHeight(t->RightRoot));
    }
    else return 0;
}

int BalanceTree::Width(int level)
{
    if(root)// if tree not empty
    {
       Queue::Queue<WidthLooking> Q;
       int width; // return value
       int height = Height();
       WidthLooking cur;
       int * WidthLevel;// array to save with of all level
       WidthLevel = new int[height];// count of level is height of tree
       for(int i = 0; i < height; i++) WidthLevel[i] = 0;//init of array
       Q.Put(WidthLooking(root,0));
       while(Q.NotEmpty())
       {
          cur = Q.Get();
          WidthLevel[cur.level]++;// needing element in array in cur.level position increment
          if(cur.link->LeftRoot) Q.Put(WidthLooking(cur.link->LeftRoot,cur.level + 1));
          if(cur.link->RightRoot) Q.Put(WidthLooking(cur.link->RightRoot,cur.level + 1));
       }

       if(level < 0)// then search max width
       {
          width = WidthLevel[0];
          for(int i = 0; i < height; i++)
          {
             if(width < WidthLevel[i]) width = WidthLevel[i];
          }
       }
       else width = WidthLevel[level];

       delete[] WidthLevel;
       return width;
    }
    else return 0;
}

int BalanceTree::RecursiveCounting(Node* Link)
{
    if(Link)
    {
       return 1 + RecursiveCounting(Link->LeftRoot) + RecursiveCounting(Link->RightRoot);
    }
    else  return 0;
}

void BalanceTree::Draw(TStringGrid *sg,int col, int row, int key)
{
     sg->Canvas->Ellipse(sg->DefaultColWidth*(col),sg->DefaultRowHeight*(row),
                         sg->DefaultColWidth*(col + 1),sg->DefaultRowHeight*(row + 1));
     sg->Canvas->TextOutA(sg->DefaultColWidth*(col+0.3),sg->DefaultRowHeight*(row+0.3),key);

}

void BalanceTree::WriteSG(Node* t,TStringGrid* sg,int left, int right, int level)
{
    if(t)
    {
       sg->Canvas->Pen->Color = clRed;
       sg->Canvas->Font->Color = clWhite;
       sg->Cells[(left+right)/2][level] = t->item;
       //Draw(sg,(left+right)/2,level,t->item);
       WriteSG(t->LeftRoot,sg,left,(left+right)/2,level+1);
       WriteSG(t->RightRoot,sg,(left+right)/2,right,level+1);
    }
}

void BalanceTree::WriteToStringGrid(TStringGrid* sg)
{
    //Change property StringGrid for our tree
    for(int i = 0; i < sg->RowCount; i++)
        for(int j = 0; j < sg->ColCount; j++)
            sg->Cells[j][i] = "";
    sg->RowCount = this->Height();
    sg->ColCount = 2*pow(2,sg->RowCount - 1);
    WriteSG(root,sg,0,sg->ColCount,0);
}

DepthIterator::DepthIterator(BalanceTree* pTree): tree(pTree)
{
    Stack.push(tree->root);//init of stack
}

int DepthIterator::Next()
{
    Node* cur = Stack.pop();
    if(cur->LeftRoot ) Stack.push(cur->LeftRoot);
    if(cur->RightRoot) Stack.push(cur->RightRoot);

    return cur->item;
}

int& DepthIterator::operator++()//++this
{
    Node* cur = Stack.pop();
    if(cur->LeftRoot ) Stack.push(cur->LeftRoot);
    if(cur->RightRoot) Stack.push(cur->RightRoot);

    return (Stack.pop())->item;
}

int& DepthIterator::operator++(int)//this++
{
  Node* cur;

  try
  {
     cur = Stack.pop();
     if(!cur)  throw EndOfTree();//then all linkig have worked
     if(cur->RightRoot) Stack.push(cur->RightRoot);
     if(cur->LeftRoot ) Stack.push(cur->LeftRoot );

     return cur->item;
  }
  catch(Stack::MyStack<Node*>::SuperClassExeption& e)
  {
     throw EndOfTree();
  }
}

void DepthIterator::operator=(BalanceTree* pTree)
{
    tree = pTree;
    Stack.DoEmpty();
    Stack.push(tree->root);
}

void DepthIterator::Done()
{
    Stack.DoEmpty();
    Stack.push(tree->root);
}

OwnIterator::OwnIterator(BalanceTree* pTree):prev(0),cur(0),next(pTree->root),down(true),
                                             working(false),tree(pTree),CountRightRoot(0)
{
    if(next)
    {
       working = true;
    }
    else
    {
       throw EmptyTree();
    }
}

int OwnIterator::Next()
{
    if(down)
    {
       if(next->LeftRoot)
       {
          /* probuem poiti v leviy uzel */
          prev = cur;
          cur = next;
          next = next->LeftRoot;
          cur->LeftRoot = prev;
       }
       else if(next->RightRoot)
       {
          /* probuem poity vpravo */
          prev = cur;               //
          cur = next;               // sdvigaem
          next = next->RightRoot;   //
          cur->RightRoot = prev;    // zamikaem nazad
          CountRightRoot++;//We must count rioght root to gooing back
       }
       else
       {
          /* razvorot i poisk blizhaishego, esli net to konez obhoda, idem vvrerh */
          prev = cur;
          cur = next;
          next = prev;
          down = false;
       }
    }
    else
    {
       throw int(1);
       down = true;
       /* prepared for iteration, and created right situtation */
       Node *tmp = prev;                         //  round
       prev = cur;                               //  round
       cur = tmp;                                //  round
       if(cur->LeftRoot) cur->LeftRoot = prev;   //  round
       else                                      //    .
       {                                         //    .
         cur->RightRoot = prev;                  //    .
         CountRightRoot--;                       //    .
       }                                         //  round
       /* go up */
       while(next->RightRoot && CountRightRoot)
       {
             if(next->RightRoot)
             {
                prev = cur;               //
                cur = next;               // sdvigaem
                next = next->RightRoot;   //
                cur->RightRoot = prev;    // zamikaem nazad
                CountRightRoot--;
             }
             else
             {
                prev = cur;               //
                cur = next;               // sdvigaem
                next = next->LeftRoot;   //
                cur->RightRoot = prev;    // zamikaem nazad
             }
             if(CountRightRoot < 0) throw "Unnormal situation, variable CountRightRoot";//for programist
       }
       prev = cur;               //
       cur = next;               // sdvigaem
       next = next->RightRoot;   //
       if(next->LeftRoot)//go to the left subtree
       {
          prev = cur;               //
          cur = next;               // sdvigaem
          next = next->LeftRoot;   //
          cur->RightRoot = prev;    // zamikaem
       }
       else if(next->RightRoot)// ... right subtree
       {
          prev = cur;               //
          cur = next;               // sdvigaem
          next = next->RightRoot;   //
          cur->RightRoot = prev;    // zamikaem
       }
       else// link is leave
       {
          prev = cur;
          next = cur;
          prev = next;
          down = false;
       }
    }
    return cur->item;
}

void OwnIterator::Reconstruct()
{   /*
    next = cur;
    cur = prev;
    if(prev->LeftRoot) prev = prev->LeftRoot;
    else prev = prev->RightRoot;
    while(prev != tree->root)
    {
       cur->LeftRoot = next;
       next = cur;
       cur = prev;
       if(prev->LeftRoot) prev = prev->LeftRoot;
       else prev = prev->RightRoot;
    }*/
    while(next != tree->root)
    {
       prev = cur;
       cur = next;

       if(next->LeftRoot)
       {
          next = next->LeftRoot;
       }
       else
       {
         next = next->RightRoot;
       }
       cur->LeftRoot = prev;
    }

    next->LeftRoot = cur;//becouse root->left point to NULL
}

WidthIterator::WidthIterator(BalanceTree *pTree) : tree(pTree)
{
    Queue.Put(tree->root);
}

int& WidthIterator::operator++()//++this
{
    if(Queue.IsEmpty()) throw EndOfTree();
    Node* cur = Queue.Get();
    if(cur->RightRoot) Queue.Put(cur->RightRoot);
    if(cur->LeftRoot ) Queue.Put(cur->LeftRoot);

    return (Queue.Get())->item;
}

int& WidthIterator::operator++(int)//this++
{
  Node *cur;
  try
  {
    cur = Queue.Get();
    if(!cur) throw EndOfTree();//becouse all linkig have worked
    if(cur->LeftRoot ) Queue.Put(cur->LeftRoot );
    if(cur->RightRoot) Queue.Put(cur->RightRoot);

    return cur->item;
  }
  catch(Queue::Queue<Node*>::EmptyQueue e)
  {
    throw EndOfTree();
  }
}

int WidthIterator::Next()//*(this)++
{
  Node* cur;

  if(Queue.IsEmpty()) throw EndOfTree();
  cur = Queue.Get();
  if(!cur) throw EndOfTree();//becouse all linkig have worked
  if(cur->LeftRoot ) Queue.Put(cur->LeftRoot );
  if(cur->RightRoot) Queue.Put(cur->RightRoot);

  return cur->item;
}

void WidthIterator::operator=(BalanceTree* pTree)
{
    tree = pTree;
    Queue.DoEmpty();
    Queue.Put(tree->root);
}

void WidthIterator::Done()
{
    Queue.DoEmpty();
    Queue.Put(tree->root);
}
