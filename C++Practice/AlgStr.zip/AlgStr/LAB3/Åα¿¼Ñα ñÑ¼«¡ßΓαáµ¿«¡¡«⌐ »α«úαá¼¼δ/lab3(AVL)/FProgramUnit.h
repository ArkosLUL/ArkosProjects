//---------------------------------------------------------------------------

#ifndef FProgramUnitH
#define FProgramUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFProgram : public TForm
{
__published:	// IDE-managed Components
        TRichEdit *RichEdit1;
        TBitBtn *BitBtn1;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall RichEdit1KeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
        __fastcall TFProgram(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFProgram *FProgram;
//---------------------------------------------------------------------------
#endif
