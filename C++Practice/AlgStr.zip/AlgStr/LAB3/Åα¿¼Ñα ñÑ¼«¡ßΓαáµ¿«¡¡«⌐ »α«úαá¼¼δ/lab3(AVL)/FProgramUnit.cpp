//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FProgramUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFProgram *FProgram;
//---------------------------------------------------------------------------
__fastcall TFProgram::TFProgram(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFProgram::FormActivate(TObject *Sender)
{
  FProgram->Left = Screen->Width / 2 - FProgram->Width / 2;
  FProgram->Top  = Screen->Height / 2 - FProgram->Height / 2;

  BitBtn1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFProgram::FormCreate(TObject *Sender)
{
  try
  {
     RichEdit1->Lines->LoadFromFile("AboutProgram.txt");
  }
  catch(...)
  {
     MessageDlg("File \"AboutProgram.txt\" wasn't found!\nYou cannot looking information about program",
                 mtError, TMsgDlgButtons() << mbOK, 0);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFProgram::RichEdit1KeyPress(TObject *Sender, char &Key)
{
  Key = 0;        
}
//---------------------------------------------------------------------------
