/*                                                                  *\
| "��������� ������������ ������ ��� ������"                          |                             |
\*                                                                  */
//---------------------------------------------------------------------------

#ifndef QueueH
#define QueueH
//---------------------------------------------------------------------------

namespace Queue
{
 template <class T>
 struct link
 {
     T information;
     link<T> * next;

     link() : next(0) {};
 };

 template <class T>
 class Queue
 {
 private:
     link<T> * begin;
     link<T> * end;

 public:
      //Exeption
      class SuperClass {};
      class EmptyQueue:SuperClass{};
      
      Queue():begin(0),end(0) {};
      
      ~Queue()
      {
           if(begin)
           {
              link<T> * del;

              while (begin->next)
              {
                     del  = begin;
                     begin = begin->next;
                     delete del;
              }
              delete begin;
           }
      };

      //Main functions
      void Put(T add)
      {
              link<T> * NewLink;
              NewLink = new link<T>;
              NewLink->information = add;
              NewLink->next = begin;
              begin = NewLink;
              if(!begin->next)
              {
                 end = begin;//if Empty int end
              }
      };
      
      T Get()
      {
              if(begin)
              {
                 T ret;
                 link<T> * del;
                 if(begin == end)//one element
                 {
                    ret = end->information;
                    del = end;
                    begin = 0; end = 0;//dangerest from wild pointer
                 }
                 else
                 {
                    ret = end->information;
                    del = end;
                    end = begin;
                    while(end->next != del)//end must point to end of queue
                    {
                          end = end->next;
                    }
                    end->next = 0;
                 }
                 delete del;
                 return ret;
              }
              else
              {
                 throw EmptyQueue();
              }
      };

      void DoEmpty()
      {
           if(begin)
           {
              link<T> * del;

              while (begin->next)
              {
                     del  = begin;
                     begin = begin->next;
                     delete del;
              }
              delete begin;
           }
           begin = 0;
           end = 0;
      };

      int GetCount() const
      {
              int count(0);
              link<T> * cur = begin;
              while(cur)
              {
                   cur = cur->next;
                   count++;
              }
              return count;
      };

      bool IsEmpty()  const  { return !begin; };
      bool NotEmpty() const { return begin; };
 };
}
#endif
