//---------------------------------------------------------------------------
#include <vcl.h>

#include "BalanceTree.h"
#pragma hdrstop
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TFMain *FMain;
//---------------------------------------------------------------------------
__fastcall TFMain::TFMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------



void __fastcall TFMain::FormCreate(TObject *Sender)
{
  tree = new BalanceTree();
}
//---------------------------------------------------------------------------

void __fastcall TFMain::FormDestroy(TObject *Sender)
{
  delete tree;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Quit1Click(TObject *Sender)
{
  FMain->Close();
}
//---------------------------------------------------------------------------



void __fastcall TFMain::Creator1Click(TObject *Sender)
{
  FCreator->ShowModal();        
}
//---------------------------------------------------------------------------


void __fastcall TFMain::Program1Click(TObject *Sender)
{
  FProgram->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Load1Click(TObject *Sender)
{
  if(OpenDialog1->Execute())
  {
     Timer1->Enabled = true;
     edtLevelWidth->Text = tree->Width(CSpinEdit1->Value);
     try
     {
        tree->Load(OpenDialog1->FileName);
        tree->WriteToStringGrid(SGShow);
     }
     catch(BalanceTree::FileNotExist& e)
     {
        MessageDlg("File: " + e.way + "doesnot exist!",
                   mtError, TMsgDlgButtons() << mbOK, 0);
     }
  }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Save1Click(TObject *Sender)
{
   if(SaveDialog1->Execute())
   {
     try
     {
        tree->Save(SaveDialog1->FileName);
     }
     catch(BalanceTree::FileNotExist& e)
     {
        MessageDlg("File: " + e.way + "doesnot exist!",
                   mtError, TMsgDlgButtons() << mbOK, 0);
     }
   }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::BitBtn1Click(TObject *Sender)
{
   if(edtAdd->Text.Length()) tree->AddItem(StrToInt(edtAdd->Text));
   Timer1->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::BitBtn2Click(TObject *Sender)
{
  try
  {
     if(edtDelete->Text.Length())  tree->DeleteItem(StrToInt(edtDelete->Text));
  }
  catch(BalanceTree::KeyNotExist& e)
  {
     MessageDlg("Key " + IntToStr(e.key) + " doesn't exist in the tree",
                mtError, TMsgDlgButtons() << mbOK, 0);
  }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::sbDepsClick(TObject *Sender)
{
  static DepthIterator depthIt(tree);
  lblDepthTheEnd->Visible = false;
  try
  {
     MemoDeps->Lines->Add(depthIt++);
  }
  catch(DepthIterator::EndOfTree& e)
  {
     lblDepthTheEnd->Visible = true;
     depthIt.Done();
     MemoDeps->Lines->Clear();
  }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::sbWidthClick(TObject *Sender)
{
  static WidthIterator widthIt(tree);
  lblWidthTheEnd->Visible = false;
  try
  {
     MemoWidth->Lines->Add(widthIt++);
  }
  catch(WidthIterator::EndOfTree& e)
  {
     lblWidthTheEnd->Visible = true;
     widthIt.Done();
     MemoWidth->Lines->Clear();
  }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Timer1Timer(TObject *Sender)
{
  Height = tree->Height();
  CSpinEdit1->MaxValue = Height - 1;
  edtHeight->Text = Height;
  Width = tree->Width();
  edtWidth->Text = Width;
  edtCount->Text = tree->Count();
  edtLevelWidth->Text = tree->Width(CSpinEdit1->Value);
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Height1Click(TObject *Sender)
{
  MessageDlg("It is height of tree: " + IntToStr(tree->Height()),
              mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------

void __fastcall TFMain::CSpinEdit1Change(TObject *Sender)
{
  edtLevelWidth->Text = tree->Width(CSpinEdit1->Value);
  if(CSpinEdit1->MaxValue == 0) CSpinEdit1->Value = 0;// if CSpinEdit1->MaxValue == 0
                                                      // then upper limited not exist
                                                      // we creat upper limit our hand
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Width1Click(TObject *Sender)
{
  MessageDlg("It is width of tree: " + IntToStr(tree->Width()),
              mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Widthonlevel1Click(TObject *Sender)
{
  MessageDlg("It is width of tree: " + IntToStr(tree->Width(CSpinEdit1->Value)),
              mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------


void __fastcall TFMain::Deps1Click(TObject *Sender)
{
  sbDeps->Click();        
}
//---------------------------------------------------------------------------

void __fastcall TFMain::Width2Click(TObject *Sender)
{
  sbWidth->Click();        
}
//---------------------------------------------------------------------------

void __fastcall TFMain::SGShowDblClick(TObject *Sender)
{
  tree->WriteToStringGrid(SGShow);        
}
//---------------------------------------------------------------------------

void __fastcall TFMain::edtAddKeyPress(TObject *Sender, char &Key)
{
 if (Key != '\b')
 {
     if (!(Key <= '9' && '0' <= Key) &&
           !(!dynamic_cast<TEdit*>(Sender)->Text.Length() && Key == '-'))
     {
         Key = 0;
     }
 }
}
//---------------------------------------------------------------------------


void __fastcall TFMain::edtAddKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if(Key == 13)
  {
     if(edtAdd->Text.Length())
     {
        tree->AddItem(StrToInt(edtAdd->Text));
        edtAdd->Text = "";
        tree->WriteToStringGrid(SGShow);
     }
  }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::edtDeleteKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if(Key == 13)
  {
     if(edtDelete->Text.Length())
     {
        BitBtn2->Click();
        edtDelete->Text = "";
        tree->WriteToStringGrid(SGShow);
     }
  }
}
//---------------------------------------------------------------------------


void __fastcall TFMain::Timer2Timer(TObject *Sender)
{
  tree->WriteToStringGrid(SGShow);
}
//---------------------------------------------------------------------------


void __fastcall TFMain::Treeisbalance1Click(TObject *Sender)
{
  MessageDlg("AVL tree always is balance. :)",
             mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------



