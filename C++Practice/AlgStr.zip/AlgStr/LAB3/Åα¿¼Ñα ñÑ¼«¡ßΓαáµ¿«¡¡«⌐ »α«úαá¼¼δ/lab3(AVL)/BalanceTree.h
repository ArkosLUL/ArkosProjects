/*                                                                  *\
| "��������� ������������ ������ ��� ������"                          |
|  �������� ���������� ���������� ����������                          |
|  ������� ��������������� ����������� ���                            |
|  ������ �� 06-2                                                     |
|  ___________________________________________________________________|
|  ��������� ��������� ���������                                 */
//---------------------------------------------------------------------------

#ifndef BalanceTreeH
#define BalanceTreeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>

#include "FCreatorUnit.h"
#include "FProgramUnit.h"
#include "ClassBalanceTree.h"
#include <Buttons.hpp>
#include <Menus.hpp>
#include <Graphics.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TFMain : public TForm
{
__published:	// IDE-managed Components
        TMemo *MemoDeps;
        TPanel *panelMain;
        TPanel *panelShowing;
        TGroupBox *BGIterators;
        TMemo *MemoWidth;
        TSpeedButton *sbDeps;
        TSpeedButton *sbWidth;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Modificators1;
        TMenuItem *Looking1;
        TMenuItem *Iterators1;
        TMenuItem *About1;
        TMenuItem *N1;
        TMenuItem *Quit1;
        TMenuItem *Load1;
        TMenuItem *Save1;
        TPanel *panelLooking;
        TLabel *Label2;
        TStringGrid *SGShow;
        TMenuItem *Add1;
        TMenuItem *Delete1;
        TMenuItem *Height1;
        TMenuItem *Width1;
        TMenuItem *Widthonlevel1;
        TMenuItem *Deps1;
        TMenuItem *Width2;
        TMenuItem *Creator1;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TLabel *lblDepthTheEnd;
        TLabel *lblWidthTheEnd;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TCSpinEdit *CSpinEdit1;
        TLabel *Label6;
        TTimer *Timer1;
        TEdit *edtHeight;
        TEdit *edtWidth;
        TEdit *edtLevelWidth;
        TLabel *Label7;
        TEdit *edtCount;
        TTimer *Timer2;
        TMenuItem *Treeisbalance1;
        TPanel *panelSimpleModificators;
        TGroupBox *GBDeleteing;
        TEdit *edtAdd;
        TBitBtn *BitBtn1;
        TGroupBox *GroupBox2;
        TBitBtn *BitBtn2;
        TEdit *edtDelete;
        TImage *imgRazd;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall Quit1Click(TObject *Sender);
        void __fastcall Creator1Click(TObject *Sender);
        void __fastcall Program1Click(TObject *Sender);
        void __fastcall Load1Click(TObject *Sender);
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall sbDepsClick(TObject *Sender);
        void __fastcall sbWidthClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Height1Click(TObject *Sender);
        void __fastcall CSpinEdit1Change(TObject *Sender);
        void __fastcall Width1Click(TObject *Sender);
        void __fastcall Widthonlevel1Click(TObject *Sender);
        void __fastcall Deps1Click(TObject *Sender);
        void __fastcall Width2Click(TObject *Sender);
        void __fastcall SGShowDblClick(TObject *Sender);
        void __fastcall edtAddKeyPress(TObject *Sender, char &Key);
        void __fastcall edtAddKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall edtDeleteKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall Treeisbalance1Click(TObject *Sender);
private:	// User declarations
        BalanceTree *tree;
        int Height;
        int Width;
public:		// User declarations
        __fastcall TFMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFMain *FMain;
//---------------------------------------------------------------------------
#endif
