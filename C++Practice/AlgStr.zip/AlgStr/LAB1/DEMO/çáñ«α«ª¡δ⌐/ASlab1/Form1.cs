﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;



namespace ASlab1
{f
    public partial class mainFRM : Form
    {
       
        public mainFRM()
        {
            InitializeComponent();
           
           
        }
        public enum TOD { List, Massive, Hash, Tree };
        private ListStruct TemporaryDataHolder
        { get; set; } 
       

        public void initDataGrid(DataGridView DG)
            
        {
            
            DG.Rows.Clear();
            DG.RowCount = 0;
            DG.ColumnCount=2;
            DGTab.AllowUserToAddRows = false;
            DG.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            DG.Columns[0].HeaderText = "Ключ";
            DG.Columns[1].HeaderText = "ТХТ-инфо";

            DG.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
            DG.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
                      
            //CMsaveAs.Enabled = true;
            
            
        }

        private void SaveData(string name)
        {
            TemporaryDataHolder.SaveRecords(name);
        }
        private void OpenData(string name)
        {
            TemporaryDataHolder = new ListStruct(DGTab);
            TemporaryDataHolder.OpenRecords(name);
            TemporaryDataHolder.FillDG();
            
            CMsave.Enabled = false;
            CMsaveAs.Enabled = true;
            PNLcup.Enabled = true;
           
            
        }
        //▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
        //обработчики сюда↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
        private void CMexit_Click(object sender, EventArgs e)
        {
             Close();
        }
        private void CMsave_Click(object sender, EventArgs e)
        {

            SaveData(OPNdialog.FileName); CMsave.Enabled = false;
        }
        private void CMsaveAs_Click(object sender, EventArgs e)
        {
            if (SVdialog.ShowDialog() == DialogResult.OK) SaveData(SVdialog.FileName);
        }
        private void CMopen_Click(object sender, EventArgs e)
        {
            if (OPNdialog.ShowDialog() == DialogResult.OK)
                OpenData(OPNdialog.FileName);

        }
      
        private void Form1_Load(object sender, EventArgs e)
        {// пишем хоткеи 
            CMexit.ShortcutKeys =(Keys) Shortcut.AltF4 ;
            CMopen.ShortcutKeys =(Keys) Shortcut.CtrlO;
            CMsave.ShortcutKeys = (Keys)Shortcut.CtrlS;
            CMsaveAs.ShortcutKeys = (Keys)Shortcut.CtrlShiftS;
            CMsaveAs.Enabled =true;
            //инит комбоЧусБокс
            ChoseBox.Items.Clear();
            ChoseBox.Items.Add("Простой последовательный поиск");
            ChoseBox.Items.Add("Быстрый последовательный поиск");
            ChoseBox.Items.Add("Поиск В упорядоченной таблице");
            ChoseBox.Items.Add("Быстрый посл. поиск+Самоорганизующийся файл");
            ChoseBox.Items.Add("Бинарный поиск");
            
            ChoseBox.Items.Add("Сортировка методом Хоара");
            ChoseBox.Items.Add("Сортировка методом Пузырька");
            ChoseBox.Items.Add("Сортировка методом подсчёта инверсий");
            ChoseBox.Items.Add("Сортировка методом прямого выбора");
            ChoseBox.Items.Add("Сортировка методом слияния");
            ChoseBox.Items.Add("Сортировка однородный бинарный поиск");
            //ChoseBox.Items.Add("Поиск в Hash-таблице");
            ChoseBox.SelectedIndex = 0;
            //▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            
            initDataGrid(DGTab);
            PNLcup.Enabled = true;

        }










        private void DoIt_Click(object sender, EventArgs e)
        {
            if (ChoseBox.SelectedIndex == -1 && ChoseBox.SelectedIndex < 5 && KeyTbox.Text == "")
            {
               MessageBox.Show("Пустое поле ввода ключа.","Уведомление", MessageBoxButtons.OK,MessageBoxIcon.Error) ;  
            }
            else 
                PerformAlg(ChoseBox.SelectedIndex);
        }
        private void PerformAlg(int SelectedMethod)
        {
            switch (SelectedMethod)//

                {
                    case 0:
                        {
                            var Lst = new ListStruct(DGTab);
                            Lst.GetRecordsFromVirtual(TemporaryDataHolder);
                            TabStud result = Lst.SimpleSearch(KeyTbox.Text);
                            ShowResult(result);
                            
                        }
                        break;
                    case 1:
                        {
                            var Lst = new ListStruct(DGTab);
                            Lst.GetRecordsFromVirtual(TemporaryDataHolder);
                            TabStud result = Lst.FastSimpleSearch(KeyTbox.Text);
                            ShowResult(result);
                        }
                        break;
                    case 2:
                        {
                            var Lst = new ListStruct(DGTab);
                            Lst.GetRecordsFromVirtual(TemporaryDataHolder);
                            TabStud result = Lst.SortedSearch(KeyTbox.Text);
                            ShowResult(result);
                        }
                        break;
                    case 3:
                        {
                            var Lst = new ListStruct(DGTab);
                            Lst.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили временный список
                            TabStud result = Lst.SelfOrganizatedList(KeyTbox.Text);
                            ShowResult(result);
                           TemporaryDataHolder= Lst.SetRecordsToVirtual();
                            initDataGrid(DGTab);
                            Lst.FillDG();
                        }
                        break;
                    case 4:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            //так как массив не изменяется в процессе поиска то перезаписывать в TemporaryDataHolder нет смысла;
                            TabStud result = Mssv.BinarySearch(KeyTbox.Text);
                            ShowResult(result);
                        }
                        break;
                    case 5:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили это временное вместилище
                            Mssv.QuickSort();//вызвали сортировку;
                            TemporaryDataHolder = Mssv.SetRecordsToVirtual();
                            Mssv.FillDG();
                            MessageBox.Show("Структура отсортирована", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                    case 6:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили это временное вместилище
                            Mssv.BulbSort();//вызвали сортировку;
                            TemporaryDataHolder = Mssv.SetRecordsToVirtual();
                            Mssv.FillDG();
                            MessageBox.Show("Структура отсортирована", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                    case 7:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили это временное вместилище
                            Mssv.PSort();//вызвали сортировку;
                            TemporaryDataHolder = Mssv.SetRecordsToVirtual();
                            Mssv.FillDG();
                            MessageBox.Show("Структура отсортирована", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                    case 8:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили это временное вместилище
                            Mssv.SelectSort();//вызвали сортировку;
                            TemporaryDataHolder = Mssv.SetRecordsToVirtual();
                            Mssv.FillDG();
                            MessageBox.Show("Структура отсортирована", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                    case 9:
                        {
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            TemporaryDataHolder = null;//очистили это временное вместилище
                            Mssv.Records = Mssv.mergeSort(Mssv.Records); ;//вызвали сортировку;
                            TemporaryDataHolder = Mssv.SetRecordsToVirtual();
                            Mssv.FillDG();
                            MessageBox.Show("Структура отсортирована", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        break;
                    case 10:
                        {

                            //TemporaryDataHolder = new ListStruct(DGTab);
                            //if (OPNdialog.ShowDialog() == DialogResult.OK)
                            //    TemporaryDataHolder.OpenRecords(OPNdialog.FileName);
                            var Mssv = new Massive(DGTab);
                            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
                            //TemporaryDataHolder = null;//очистили это временное вместилище
                            int[] coef = new int[(int)(Math.Truncate(Math.Log10(TemporaryDataHolder.counter)) + 2) + 3];
                            for (int i = 1; i <= (int)(Math.Truncate(Math.Log10(TemporaryDataHolder.counter)) + 2) + 1; i++)
                                coef[i] = (int)((TemporaryDataHolder.counter) + Math.Pow(2, i - 1)) / (int)Math.Pow(2.0, i);
                            coef[(int)Math.Truncate(Math.Log10(TemporaryDataHolder.counter)) + 2 + 2]=0;
                            TabStud result = Mssv.HomoBinarySearch(KeyTbox.Text, coef); ;//вызвали
                            ShowResult(result);
                        }
                        break;
                    //case 10:
                    //    {
                    //        var ht = new Hash();
                    //        ht.GetRecordsFromVirtual(TemporaryDataHolder);
                    //        TabStud result = ht.FindInHash(KeyTbox.Text);

                    //        if (result != null)
                    //            MessageBox.Show(result.Key + ' ' + result.Txtinfo);
                    //        else MessageBox.Show("Нет совпадений");

                    //    }
                    //    break;
                }
            CMsave.Enabled = true;
        }

        private static void ShowResult(TabStud result)
        {
            if (result != null)
                MessageBox.Show("Ключ: " + result.Key + "\nTxt-инфо: " + result.Txtinfo, "Результаты поиска",  MessageBoxButtons.OK  , MessageBoxIcon.Information);
            else MessageBox.Show("Нет совпадений", "Результаты поиска", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TemporaryDataHolder = new ListStruct(DGTab);
            if (OPNdialog.ShowDialog() == DialogResult.OK)
                TemporaryDataHolder.OpenRecords(OPNdialog.FileName);
            var Mssv = new Massive(DGTab);
            Mssv.GetRecordsFromVirtual(TemporaryDataHolder);
            //TemporaryDataHolder = null;//очистили это временное вместилище
            int[] coef = new int[(int)(Math.Truncate(Math.Log10(TemporaryDataHolder.counter)) + 2)+2];
            for (int i = 1; i <= (int)(Math.Truncate(Math.Log10(TemporaryDataHolder.counter)) + 2)+1; i++)
                coef[i] = (int)((TemporaryDataHolder.counter) + Math.Pow(2, i - 1)) / (int)Math.Pow(2.0, i);
            
                TabStud result = Mssv.HomoBinarySearch("пз10111", coef); ;//вызвали
                ShowResult(result);
            Mssv.FillDG();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Выполнил студент: Задорожный Сергей.\nПредмет: Алгоритмы и структуры.\nВ данной лабараторной работе реализованы алгоритмы поиска:\n" +
        "\nПростой последовательный поиск\n" +
          "Быстрый последовательный поиск\n" +
          "Поиск В упорядоченной таблице\n" +
          "Быстрый посл. поиск+Самоорганизующийся файл\n"
          + "Бинарный поиск \nСортировка однородный бинарный поиск" +
          "\n\nАлгоритмы сортировки:\n "

            + "Сортировка методом Хоара\n" +
            "Сортировка методом Пузырька\n" +
            "Сортировка методом подсчёта инверсий\n" +
            "Сортировка методом прямого выбора\n" +
           "Сортировка методом слияния\n5.04.11 \nОсобенности реализации:\n\nВременное хранилише информации на базе списка между реализациями алгоритмов. ", "Описание лабараторной работы №1", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
        
        }

        private void OPNdialog_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
