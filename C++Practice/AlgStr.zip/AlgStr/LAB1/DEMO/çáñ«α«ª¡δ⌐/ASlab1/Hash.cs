﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.IO;
//using System.Text;

//namespace ASlab1
//{
//    class Hash
//    {
//        public  ListStruct[] Table { get; set; }
//        public int counter { get; set; }
//        public  void PutRecord(TabStud rec)
//        {
//            //TabStud tmp;
//            int i=GetHashCode(rec.Key);
//            if (this.Table[i] == null)
//            {
//                this.Table[i] = new ListStruct();
//            }
//            else
//            {

//                table[.AddRecord(rec, Table[i]);
//            }
//        }
//        //public  void OpenTable(string name,System.Windows.Forms.DataGridView DGV)
//        //{
//        //    StreamReader reader = File.OpenText(name);
//        //    string line; string[] fields;
//        //    if (!reader.EndOfStream)
//        //    {
//        //        int count = Convert.ToInt32(reader.ReadLine());
//        //        int len = Convert.ToInt32(count * 1.2);
//        //        DGV.RowCount = count;
//        //        Table = new TabStud[len];
//        //        for (int i = 0; i < count; i++)
//        //        {
                    
//        //            line = reader.ReadLine();
//        //            line = line.Trim();
//        //            fields = line.Split('_');//шайтанама над строками . разбиваем по разделителю _
//        //            TabStud TMPrec = new TabStud();
//        //            TMPrec.Key = fields[0];
//        //            TMPrec.Txtinfo = fields[1];// прописали поля
//        //            PutRecord(TMPrec);
//        //            DGV[0, i].Value = TMPrec.Key;
//        //            DGV[1, i].Value = TMPrec.Txtinfo;

//        //        }
//        //    }

//        //}
//        public void GetRecordsFromVirtual(ListStruct source)
//        {
//            this.counter = source.counter;
//            TabStud Record = source.ListRecord;//обьявили и присвоили запись шоб ходить по списку не изменяя головы

//            this.Table = new TabStud[source.counter*2];
//            for (int i = 0; i < source.counter; i++)
//            {

//                PutRecord( Record);
//                Record = Record.Next;
//            }
            
//        }
//        public  int GetHashCode(string key)
//        {int i=0,sent,result=0;
//           sent=(key.Length<5)?key.Length:5;
           
//           while (i < sent)
//           {
//               result += key[key.Length - 1 - i]-32;
//               i++;
//           }
//           return result % Table.Length ;
//        }
//        public TabStud FindInHash(string lookingKey)
//        {int i=GetHashCode(lookingKey);
//            TabStud rec = Table[i];
        
//            if(rec!=null)
            
//            while (rec.Key != lookingKey && rec.Next!=null )
//                rec = rec.Next;
//            return (rec.Key==lookingKey)?  rec:null;
//        }
//        public  void clear()
//        {
//            if (Table!=null)
//            for (int i = 0; i < Table.Length; i++)
//            {
//                Table[i] = null;
//            }
//            GC.Collect();
//        }
//    }
//}
