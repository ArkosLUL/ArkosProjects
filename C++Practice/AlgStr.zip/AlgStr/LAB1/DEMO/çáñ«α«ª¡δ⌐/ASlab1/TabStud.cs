﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASlab1
{
 
    class TabStud
    {
        public TabStud()
        { }
        public TabStud(TabStud rec)
        { 
        this.Key = rec.Key;
        this.Txtinfo = rec.Txtinfo;
        this.Next = rec.Next;
        }
        public string Key;
        public string Txtinfo;
           
        private TabStud FNext;
        public TabStud Next
        {
            get { return FNext; }
            set { FNext = value; }
        }
      /*  private TabStud FPrev;
        public TabStud Prev
        {
            get { return FPrev; }
            set { FPrev = value; }
        }*/
       
      
    }
}
