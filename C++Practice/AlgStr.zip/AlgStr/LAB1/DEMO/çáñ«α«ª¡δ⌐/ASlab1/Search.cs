﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ASlab1
{
    class Search
    {
        public static TabStud SimpleSearch(string LookingKey, TabStud Record)
        {
            LookingKey = LookingKey.ToLower();
            while (Record != null && Record.Key != LookingKey)
            {
                Record = Record.Next;
            }
            return Record;
        }

        public static TabStud FastSimpleSearch(string LookingKey, TabStud Record)
        {
           LookingKey = LookingKey.ToLower();
           ListMetods.LastOf.Next=new TabStud();//Добавляем фиктивную запись
           ListMetods.LastOf.Next.Key = LookingKey;//с искомым ключём
            while (Record.Key != LookingKey)
            {
                Record = Record.Next;
            }
            ListMetods.LastOf.Next = null;//убили фиктивную запись
            return Record;
        }
        public static TabStud SortedSearch(string LookingKey, TabStud Record)
        {
            LookingKey = LookingKey.ToLower();
            ListMetods.LastOf.Next = new TabStud();//добавляем фиктивную запись
            ListMetods.LastOf.Next.Key =  "ЯЯЯЯЯЯЯЯ";//с бесконечным ключём для таблицы
            while (LookingKey.CompareTo(Record.Key)==1)
            {
                Record = Record.Next;
            }
            TabStud Res;
            if (LookingKey.CompareTo(Record.Key) == 0)
                Res = Record;
            else
                Res = null;
            ListMetods.LastOf.Next = null;//убили фиктивную запись
            return Res;
        }

        public static TabStud SelfOrganizatedList(string LookingKey, TabStud  Record)
        {
            LookingKey = LookingKey.ToLower();
            ListMetods.LastOf.Next = new TabStud();//Добавляем фиктивную запись
            ListMetods.LastOf.Next.Key = LookingKey;//с искомым ключём
            TabStud Blink=null,tmp=null;
            while (Record.Key != LookingKey)
            {
                Blink = Record;
                Record = Record.Next;
                
            }
           
            if (Blink != null )//если предыдущий равно нул, то нашли 1й элемент и ничё переставлять ненадо
            {
               // ставим в голову 
                if (Record.Next.Next != null)
                {
                    Blink.Next = Record.Next;//если запись в серидинке то линкуем соседей
                }
                else
                { 
                    ListMetods.LastOf = Blink;//если в конце то ласт оф переназначаем
                }
                Record.Next = ListMetods.ListRecord;
                tmp = ListMetods.ListRecord;
                ListMetods.ListRecord = Record;
                Record = tmp;
                ListMetods.ListRecord.Next = Record;
                
            }

            ListMetods.LastOf.Next = null;//убили фиктивную запись
            return  ListMetods.ListRecord;
        }

        public static TabStud BinarySearch(string LookingKey, TabStud[] Mass)
        {
            int left, right, i;
            left = 0;
            right = Mass.GetLength(0)-1;
            i = (left + right) / 2;
            while (LookingKey.CompareTo(Mass[i].Key) != 0 && left <=right  ) //do
            {
               
                if (LookingKey.CompareTo(Mass[i].Key) == -1)
                {
                    right = i - 1;
                }
                else
                {
                    left = i + 1;
                }
               i = (left + right) / 2;
            }
            

            return (left>right)?null:Mass[i];
        }

        
    }
}
