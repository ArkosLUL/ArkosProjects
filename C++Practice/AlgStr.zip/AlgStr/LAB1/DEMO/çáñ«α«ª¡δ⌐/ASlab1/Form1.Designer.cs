﻿namespace ASlab1
{
    partial class mainFRM
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.PNLgrid = new System.Windows.Forms.Panel();
            this.DGTab = new System.Windows.Forms.DataGridView();
            this.OPNdialog = new System.Windows.Forms.OpenFileDialog();
            this.SVdialog = new System.Windows.Forms.SaveFileDialog();
            this.PNLcup = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.KeyTbox = new System.Windows.Forms.TextBox();
            this.DoIt = new System.Windows.Forms.Button();
            this.ChoseBox = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.File = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.CMopen = new System.Windows.Forms.ToolStripMenuItem();
            this.CMsave = new System.Windows.Forms.ToolStripMenuItem();
            this.CMsaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.CMexit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.PNLgrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGTab)).BeginInit();
            this.PNLcup.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNLgrid
            // 
            this.PNLgrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PNLgrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PNLgrid.Controls.Add(this.DGTab);
            this.PNLgrid.Location = new System.Drawing.Point(26, 27);
            this.PNLgrid.Name = "PNLgrid";
            this.PNLgrid.Size = new System.Drawing.Size(640, 296);
            this.PNLgrid.TabIndex = 1;
            // 
            // DGTab
            // 
            this.DGTab.AllowUserToAddRows = false;
            this.DGTab.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.DGTab.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.DGTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGTab.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.DGTab.Location = new System.Drawing.Point(0, 0);
            this.DGTab.Name = "DGTab";
            this.DGTab.ReadOnly = true;
            this.DGTab.RowHeadersVisible = false;
            this.DGTab.Size = new System.Drawing.Size(636, 292);
            this.DGTab.TabIndex = 1;
            // 
            // OPNdialog
            // 
            this.OPNdialog.DefaultExt = "*.sip";
            this.OPNdialog.FileName = "*.sip";
            this.OPNdialog.Filter = "Файлы с данными|*.sip|Все файлы|*.*";
            this.OPNdialog.InitialDirectory = "C:\\Users\\Owner\\Documents\\test";
            this.OPNdialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OPNdialog_FileOk);
            // 
            // SVdialog
            // 
            this.SVdialog.DefaultExt = "*.sip";
            this.SVdialog.Filter = "Файлы с данными|*.sip|Все файлы|*.*";
            this.SVdialog.InitialDirectory = "C:\\Users\\Owner\\Documents\\test\\";
            // 
            // PNLcup
            // 
            this.PNLcup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PNLcup.Controls.Add(this.label2);
            this.PNLcup.Controls.Add(this.label1);
            this.PNLcup.Controls.Add(this.KeyTbox);
            this.PNLcup.Controls.Add(this.DoIt);
            this.PNLcup.Controls.Add(this.ChoseBox);
            this.PNLcup.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.PNLcup.Location = new System.Drawing.Point(26, 329);
            this.PNLcup.Name = "PNLcup";
            this.PNLcup.Size = new System.Drawing.Size(638, 87);
            this.PNLcup.TabIndex = 3;
            this.PNLcup.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Алгоритм";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Искомый ключ";
            // 
            // KeyTbox
            // 
            this.KeyTbox.Location = new System.Drawing.Point(95, 18);
            this.KeyTbox.Name = "KeyTbox";
            this.KeyTbox.Size = new System.Drawing.Size(201, 20);
            this.KeyTbox.TabIndex = 2;
            // 
            // DoIt
            // 
            this.DoIt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DoIt.Location = new System.Drawing.Point(479, 48);
            this.DoIt.Name = "DoIt";
            this.DoIt.Size = new System.Drawing.Size(155, 22);
            this.DoIt.TabIndex = 1;
            this.DoIt.Text = "Выполнить";
            this.DoIt.UseVisualStyleBackColor = true;
            this.DoIt.Click += new System.EventHandler(this.DoIt_Click);
            // 
            // ChoseBox
            // 
            this.ChoseBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChoseBox.FormattingEnabled = true;
            this.ChoseBox.ItemHeight = 13;
            this.ChoseBox.Location = new System.Drawing.Point(68, 50);
            this.ChoseBox.Name = "ChoseBox";
            this.ChoseBox.Size = new System.Drawing.Size(297, 21);
            this.ChoseBox.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.File,
            this.toolStripMenuItem3});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(694, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // File
            // 
            this.File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.CMopen,
            this.CMsave,
            this.CMsaveAs,
            this.toolStripMenuItem2,
            this.CMexit});
            this.File.Name = "File";
            this.File.Size = new System.Drawing.Size(37, 20);
            this.File.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(111, 6);
            // 
            // CMopen
            // 
            this.CMopen.Name = "CMopen";
            this.CMopen.Size = new System.Drawing.Size(114, 22);
            this.CMopen.Text = "Open";
            this.CMopen.Click += new System.EventHandler(this.CMopen_Click);
            // 
            // CMsave
            // 
            this.CMsave.Enabled = false;
            this.CMsave.Name = "CMsave";
            this.CMsave.Size = new System.Drawing.Size(114, 22);
            this.CMsave.Text = "Save";
            this.CMsave.Click += new System.EventHandler(this.CMsave_Click);
            // 
            // CMsaveAs
            // 
            this.CMsaveAs.Enabled = false;
            this.CMsaveAs.Name = "CMsaveAs";
            this.CMsaveAs.Size = new System.Drawing.Size(114, 22);
            this.CMsaveAs.Text = "Save As";
            this.CMsaveAs.Click += new System.EventHandler(this.CMsaveAs_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(111, 6);
            // 
            // CMexit
            // 
            this.CMexit.Name = "CMexit";
            this.CMexit.Size = new System.Drawing.Size(114, 22);
            this.CMexit.Text = "Exit";
            this.CMexit.Click += new System.EventHandler(this.CMexit_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(24, 20);
            this.toolStripMenuItem3.Text = "?";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(689, 86);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(18, 22);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // mainFRM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 428);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.PNLcup);
            this.Controls.Add(this.PNLgrid);
            this.Controls.Add(this.menuStrip1);
            this.MinimumSize = new System.Drawing.Size(650, 300);
            this.Name = "mainFRM";
            this.Text = "Лабораторная работа №1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PNLgrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGTab)).EndInit();
            this.PNLcup.ResumeLayout(false);
            this.PNLcup.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNLgrid;
        private System.Windows.Forms.DataGridView DGTab;
        private System.Windows.Forms.OpenFileDialog OPNdialog;
        private System.Windows.Forms.SaveFileDialog SVdialog;
        private System.Windows.Forms.GroupBox PNLcup;
        private System.Windows.Forms.ComboBox ChoseBox;
        private System.Windows.Forms.Button DoIt;
        private System.Windows.Forms.TextBox KeyTbox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem File;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem CMopen;
        private System.Windows.Forms.ToolStripMenuItem CMsave;
        private System.Windows.Forms.ToolStripMenuItem CMsaveAs;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem CMexit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
    }
}

