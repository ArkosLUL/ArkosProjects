﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace ASlab1
{
    class ListMetods
    {   public static TabStud FListRecord=new TabStud();
        public static TabStud ListRecord { get { return FListRecord; } set { FListRecord = value; } }
        //↑↑↑↑↑↑↑↑свойство которое содержит экземпляр класса табСтуд для списка

        public static TabStud LastOf { get; set; }//стат. свойство содержащее ссылку на последний рекорд

        public static void OpenRecords(string name)
        {
            
            StreamReader reader = File.OpenText(name);
            string line; string[] fields;
            TabStud   Link =  ListRecord;
            reader.ReadLine();
          //  Massive.CountRec = 1;//инициализируем счётчик колва элементов для возможно создаваемого массива
           
            while (!reader.EndOfStream)
            {
                
                line = reader.ReadLine();
                line = line.Trim();
                fields = line.Split('_');//шайтанама над строками . разбиваем по разделителю _

                ListRecord.Key = fields[0];
                ListRecord.Txtinfo = fields[1];// прописали поля
                 if (reader.EndOfStream)
                { LastOf = ListRecord; ListRecord.Next = null; }
                else
                {
                     ListRecord.Next = new TabStud();
                   //  Rtemp.Next.Prev = Rtemp;
                     ListRecord = ListRecord.Next;// Massive.CountRec++;
                    
                 }//создали сразу следущий
                         
            }
            ListRecord = Link;
          
            reader.Dispose();
            
      }
        public static void SaveRecords(string name, TabStud Rtemp)
        {
            StreamWriter writer = File.CreateText(name);
            while (Rtemp != null)
            {
                writer.WriteLine(Rtemp.Key+'_'+Rtemp.Txtinfo);
                Rtemp = Rtemp.Next;
            }
            writer.Close();
            writer.Dispose();
        }

        public static void FillDG(DataGridView DG, TabStud Rtemp)
        {
            int i = 0;
            do
            {
                DG.Rows.Insert(DG.RowCount - 1, 1);
                DG[0, i].Value = Rtemp.Key;
                
                DG[1, i].Value = Rtemp.Txtinfo;
                Rtemp = Rtemp.Next;
                i++;
            }
            while (Rtemp != null);

            DG.Enabled = true;

        }
        public static TabStud FindLastOf(TabStud Rtemp)
        {
            while (Rtemp.Next != null)
                Rtemp = Rtemp.Next;
            return Rtemp;
        }//поиск последнего рекорда в спписке

        public static void AddRecord(TabStud Radd,TabStud Rbegin)//приняли запись шо надо добавить, и указатель на начало записей(если это вдруг от обработцика NEW)
        {
            if ((LastOf=FindLastOf( Rbegin)) != null)
            { // код для добавления в уже существующий список
                LastOf.Next = Radd;
                LastOf = Radd;
              //  Massive.AddMass(Radd);
            }
            else
                // создание списка и добавление первой записи в пустой список
            {   Rbegin.Key= Radd.Key;
                Rbegin.Txtinfo = Radd.Txtinfo;
                LastOf = Rbegin;
            }
       
        }
        public static void Clear()
        {
            TabStud Rtmp;
            while (ListRecord != null) 
            {
            Rtmp = ListRecord.Next;
            ListRecord = null;
            ListRecord = Rtmp;
        }
            ListRecord = new TabStud();
        GC.Collect();
        }
    }
}
