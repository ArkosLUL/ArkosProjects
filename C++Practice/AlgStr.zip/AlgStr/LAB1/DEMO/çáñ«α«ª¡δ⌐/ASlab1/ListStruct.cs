﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace ASlab1
{
    class ListStruct
    {
        DataGridView DGV;
        public int counter { get; set; }//счётчик количества записей
        public TabStud ListRecord, LastOf;
        
        public  ListStruct(DataGridView recieverDGV=null)
        {
            counter = 0;
            DGV = recieverDGV;
            ListRecord = new TabStud();
            LastOf = ListRecord;
        }
        public  void OpenRecords(string name)
        {

            StreamReader reader = File.OpenText(name);
            string line; string[] fields;
            TabStud Link = ListRecord;
            counter= Convert.ToInt32( reader.ReadLine());
            
            while (!reader.EndOfStream)
            {

                line = reader.ReadLine();
                line = line.Trim();
                fields = line.Split('_');//шайтанама над строками . разбиваем по разделителю _

                ListRecord.Key = fields[0];
                ListRecord.Txtinfo = fields[1];// прописали поля
                ////if (reader.EndOfStream)
                ////{ LastOf = ListRecord; ListRecord.Next = null; }
                //else
                {
                    ListRecord.Next = new TabStud();
                    this.LastOf = ListRecord;
                    ListRecord = ListRecord.Next;

                }//создали сразу следущий

            }
            this.LastOf.Next = null;
            ListRecord = Link;

            reader.Dispose();

        }
        public void GetRecordsFromVirtual(ListStruct source)//ф-ия берет информацию из списка единажды прочитанного из файла
        {
            // если  в последствии используемый алгоритм изменит данные, то
            this.ListRecord= source.ListRecord;
            this.LastOf = source.LastOf;
            this.counter = source.counter;
       
        }
        public ListStruct SetRecordsToVirtual()// если  в последствии используемый алгоритм изменит данные, то 
        {//выполниим эту функцию которая вернет в место назначения список.. ток через ретурнс ибо свойства нельзя передавать как пареметр через реф!!
            
           var dest = new ListStruct(DGV);
            dest.counter = this.counter;
            dest.ListRecord = this.ListRecord;
            dest.LastOf = this.LastOf;
            return dest;
        }
        public  void SaveRecords(string name)
        {
            StreamWriter writer = File.CreateText(name);
            writer.WriteLine(counter.ToString());
            TabStud Record = (this.ListRecord);
            while (Record != null)
            {
                writer.WriteLine(Record.Key + '_' + Record.Txtinfo);
                Record = Record.Next;
            }
            writer.Close();
            writer.Dispose();
        }
        public  void FillDG()
        {
            TabStud tmpR = new TabStud(this.ListRecord);
            int i = 0;
            DGV.Rows.Clear();
            DGV.RowCount =0;
           
            do
            {
                DGV.Rows.Insert(DGV.RowCount , 1);
                DGV[0, i].Value = tmpR.Key;

                DGV[1, i].Value = tmpR.Txtinfo;
                tmpR = tmpR.Next;
                i++;
            }
            while (tmpR != null);

            DGV.Enabled = true;

        }
        public  void Clear()
        {
            TabStud Rtmp;
            while (this.ListRecord != null)
            {
                Rtmp = this.ListRecord.Next;
                this.ListRecord = null;
                this.ListRecord = Rtmp;
            }
            this.ListRecord = new TabStud();
            GC.Collect();
        }
        public void AddRecord(TabStud rec)
        {
            TabStud Record=this.ListRecord;
            while (Record != null)
                Record = Record.Next;
            rec.Next = null;
            Record = new TabStud(rec);
        }
        public TabStud SimpleSearch(string LookingKey)
        {
            TabStud tmpR = new TabStud(this.ListRecord);
            LookingKey = LookingKey.ToLower();
            while (tmpR != null && tmpR.Key != LookingKey)
            {
                tmpR = tmpR.Next;
            }
            return tmpR;
        }
        public  TabStud FastSimpleSearch(string LookingKey )
        {
            TabStud tmpR = new TabStud(this.ListRecord);
           LookingKey = LookingKey.ToLower();
           this.LastOf.Next = new TabStud();//Добавляем фиктивную запись
           this.LastOf.Next.Key = LookingKey;//с искомым ключём
           while (tmpR.Key != LookingKey)
            {
                tmpR = tmpR.Next;
            }
           this.LastOf.Next = null;//убили фиктивную запись
           return tmpR;
        }
        public  TabStud SortedSearch(string LookingKey )
        {
            TabStud Record=new TabStud(this.ListRecord);
          
            LookingKey = LookingKey.ToLower();
            this.LastOf.Next = new TabStud();//добавляем фиктивную запись
            this.LastOf.Next.Key = "ЯЯЯЯЯЯЯЯ";//с бесконечным ключём для таблицы
            while (LookingKey.CompareTo(Record.Key) == 1)
            {
                Record = Record.Next;
            }
            TabStud Res;
            if (LookingKey.CompareTo(Record.Key) == 0)
                Res = Record;
            else
                Res = null;
            this.LastOf.Next = null;//убили фиктивную запись
            return Res;
        }
        public  TabStud SelfOrganizatedList(string LookingKey)
        {

            LookingKey = LookingKey.ToLower();
            this.LastOf.Next = new TabStud();//Добавляем фиктивную запись
            this.LastOf.Next.Key = LookingKey;//с искомым ключём
            this.LastOf.Next.Txtinfo = "FakeRecord";
            TabStud Blink = null;
            TabStud Record = (this.ListRecord);
            while (Record.Key != LookingKey)
            {
                Blink = Record;
                Record = Record.Next;

            }

            this.LastOf.Next = null;//убили фиктивную запись
            if (Blink != null && Record.Txtinfo != "FakeRecord")//если предыдущий равно нул, то нашли 1й элемент и ничё переставлять ненадо
            {
                if (Record.Next == null)
                {//если запись в конце то :
                    Record.Next = this.ListRecord;
                    Blink.Next = null;
                    this.LastOf = Blink;//указали истенный последний
                    this.ListRecord = Record;
                }
                else
                {//иначе она в середине.. по этому :
                    if (Blink == this.ListRecord)
                    {
                        Blink.Next = Record.Next;
                        this.ListRecord = Record;
                        Record.Next = Blink;
                    }
                    else
                    {
                        Blink.Next = Record.Next;
                        Record.Next = this.ListRecord;
                        this.ListRecord = Record;
                        
                    }
                }
            }


            return (Record.Txtinfo != "FakeRecord")? this.ListRecord: null;
        }
    }
}
